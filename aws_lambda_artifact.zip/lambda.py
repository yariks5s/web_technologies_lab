from fastapi import FastAPI, Request
from mangum import Mangum
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

import base64
import boto3

app = FastAPI()
handler = Mangum(app)

templates = Jinja2Templates(directory="templates")

@app.get('/is_up/')
async def is_up():
    return "OK"

@app.get('/')
async def index():
    return {"Program": "this is an index page of the program"}

@app.get("/s3_storage_image/{filename}")
async def s3_storage(request: Request, filename: str):
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket='yariksbucket', Key=filename)
    data = response['Body'].read()
    base64_data = base64.b64encode(data).decode("utf-8")
    context = {"photo": base64_data}

    return templates.TemplateResponse("photo.html", {"request": request, **context})

